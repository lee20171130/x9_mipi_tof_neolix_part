﻿#ifndef __TEST__H__
#define __TEST__H__
#include"../pointcloud/rotatePlane.h"
#include"../../include/libTof.h"
#include"../neolixMV.h"
namespace neolix {

  void test_rotatePlane();
  void test_measure3D();
  void testCloud();
  void testReadFile();

}




#endif //__TEST__H__
